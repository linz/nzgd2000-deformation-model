# Namespace package - __init__.py cannot contain anything else
__import__('pkg_resources').declare_namespace(__name__)
