#!/bin/python
import sys
import os.path
sys.path.insert(0,os.path.dirname(__file__))
from LINZ.DeformationModel import ITRF_NZGD2000
ITRF_NZGD2000.main()
