#!/bin/python
import sys
import os.path
sys.path.insert(0,os.path.dirname(__file__))
from LINZ.DeformationModel import CalcDeformation
CalcDeformation.main()
