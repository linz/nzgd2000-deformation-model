#!/usr/bin/python
import sys
import os.path
sys.path.insert(1,os.path.join(os.path.dirname(os.path.abspath(__file__)),'LINZ'))
from DeformationModel import ITRF_NZGD2000
ITRF_NZGD2000.main()
