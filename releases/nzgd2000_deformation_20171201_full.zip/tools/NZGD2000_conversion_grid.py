#!/usr/bin/python
import sys
import os.path
sys.path.insert(1,os.path.join(os.path.dirname(os.path.abspath(__file__)),'LINZ'))
from DeformationModel import NZGD2000_conversion_grid
NZGD2000_conversion_grid.main()
