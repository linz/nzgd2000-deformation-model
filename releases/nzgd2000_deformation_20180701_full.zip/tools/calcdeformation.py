#!/usr/bin/python3
import sys
import os.path
sys.path.insert(1,os.path.join(os.path.dirname(os.path.abspath(__file__)),'LINZ'))
from DeformationModel import CalcDeformation
CalcDeformation.main()
